import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const routes = [
  '/',
  '/nos-livres-sur-mesure',
  '/nos-abonnements',
  '/comment-ca-marche',
  '/a-propos',
  '/blog',
  '/contact',
  '/conditions-generales',
  '/politique-confidentialite',
  '/plan-du-site',
  '/faq',
  '/panier',
  '/connexion',
  '/inscription'
];

// Read the main index.html template
const template = fs.readFileSync(
  path.resolve(__dirname, '../dist/index.html'),
  'utf-8'
);

// Create directories and index.html files for each route
routes.forEach(route => {
  if (route === '/') return; // Skip root as it's already created

  const dir = path.resolve(__dirname, '../dist', route.slice(1));
  fs.mkdirSync(dir, { recursive: true });
  fs.writeFileSync(path.resolve(dir, 'index.html'), template);
});

console.log('Static files generated successfully!');