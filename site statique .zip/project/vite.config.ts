import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { resolve } from 'path';

// List of all routes that need to be pre-rendered
const routes = [
  '/',
  '/nos-livres-sur-mesure',
  '/nos-abonnements',
  '/comment-ca-marche',
  '/a-propos',
  '/blog',
  '/contact',
  '/conditions-generales',
  '/politique-confidentialite',
  '/plan-du-site',
  '/faq',
  '/panier',
  '/connexion',
  '/inscription'
];

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  build: {
    rollupOptions: {
      input: {
        main: resolve(__dirname, 'index.html'),
        ...Object.fromEntries(
          routes.map(route => [
            route.slice(1) || 'index',
            resolve(__dirname, route === '/' ? 'index.html' : `${route}/index.html`)
          ])
        )
      }
    }
  },
  optimizeDeps: {
    exclude: ['lucide-react'],
  },
});